# Notebook 09 — Results Summary

- Dataset rows: 78,600; columns: 14
- Source SHA-256: `c7eae68df7ff627089b44df6123c4974e71065f4c342b45a4bf4664bdea6beb0`
- Validation macro-F1 champion: **ExtraTrees_balanced**
- Validation high-risk AP champion: **ExtraTrees_unweighted**

## Final test multiclass comparison
| model                       |   accuracy |   balanced_accuracy |   macro_precision |   macro_recall |   macro_f1 |   weighted_f1 |
|:----------------------------|-----------:|--------------------:|------------------:|---------------:|-----------:|--------------:|
| ExtraTrees_balanced         |   0.760702 |            0.779146 |          0.622969 |       0.779146 |   0.659721 |      0.793086 |
| LightGBM_balanced           |   0.71783  |            0.840028 |          0.631815 |       0.840028 |   0.655768 |      0.761772 |
| RandomForest_balanced       |   0.83856  |            0.67824  |          0.614579 |       0.67824  |   0.63589  |      0.8334   |
| ExtraTrees_unweighted       |   0.855798 |            0.580852 |          0.610106 |       0.580852 |   0.553867 |      0.822099 |
| LogisticRegression_balanced |   0.600916 |            0.793743 |          0.539757 |       0.793743 |   0.541047 |      0.64547  |

## Final test high-risk screening comparison
| model                       |   threshold_from_validation |   tp |   fp |   fn |    tn |   precision |   recall |       f1 |   average_precision |   roc_auc |   alerts |   illustrative_cost |
|:----------------------------|----------------------------:|-----:|-----:|-----:|------:|------------:|---------:|---------:|--------------------:|----------:|---------:|--------------------:|
| ExtraTrees_balanced         |                       0.17  | 1264 | 3972 |    3 | 10482 |    0.241406 | 0.997632 | 0.388744 |            0.253304 |  0.86663  |     5236 |                4002 |
| ExtraTrees_unweighted       |                       0.075 | 1260 | 3959 |    7 | 10495 |    0.241426 | 0.994475 | 0.388529 |            0.252507 |  0.866613 |     5219 |                4029 |
| LogisticRegression_balanced |                       0.365 | 1260 | 3966 |    7 | 10488 |    0.241102 | 0.994475 | 0.38811  |            0.252299 |  0.867287 |     5226 |                4036 |
| LightGBM_balanced           |                       0.01  | 1267 | 3977 |    0 | 10477 |    0.241609 | 1        | 0.389188 |            0.250716 |  0.86761  |     5244 |                3977 |
| RandomForest_balanced       |                       0.13  | 1251 | 3926 |   16 | 10528 |    0.241646 | 0.987372 | 0.388268 |            0.249479 |  0.866554 |     5177 |                4086 |

## Interpretation guardrail
The target is the Kaggle-provided risk label, not independently verified fraud ground truth.