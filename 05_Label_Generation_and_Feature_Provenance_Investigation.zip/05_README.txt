Notebook 05 — Label Generation and Feature Provenance Investigation

1. Open the notebook in Google Colab.
2. Upload the exact original CSV: metaverse_transactions_dataset(1).csv
3. Run all cells from top to bottom.
4. Fill in the Kaggle source record near the top using the exact dataset page.
5. Upload the completed notebook and generated files:
   - 05_feature_provenance_risk_register.csv
   - 05_provenance_summary.json

This notebook does not modify the source CSV and does not train a model.
It cannot prove the original label-generation process without Kaggle documentation,
the creator's code, or a data dictionary.
