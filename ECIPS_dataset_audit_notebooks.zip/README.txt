# ECIPS / Metaverse transaction dataset audit notebooks

Run in order:
1. `01_dataset_intake_validation.ipynb`
2. `02_label_integrity_leakage_audit.ipynb`
3. `03_feature_provenance_split_design.ipynb`
4. `04_baseline_model_after_audit.ipynb` (only after leakage review)

Place `metaverse_transactions_dataset(1).csv` in the same folder as the notebooks, or edit `DATA_PATH` at the top of each notebook.

The notebooks do not modify the original CSV. Notebook 04 is gated on completing the provenance/leakage review. The provisional exclusions are conservative and must be confirmed against the actual label-generation process.
